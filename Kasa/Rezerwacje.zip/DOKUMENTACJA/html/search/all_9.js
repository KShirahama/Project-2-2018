var searchData=
[
  ['nazwa',['Nazwa',['../class_silnik_1_1_lotnisko.html#a9f92f264a5a3b2e5a8393fff6314d4ea',1,'Silnik.Lotnisko.Nazwa()'],['../class_silnik_1_1_posrednik.html#a2f7b267d89c092873db10e7928da53d7',1,'Silnik.Posrednik.Nazwa()']]],
  ['nazwisko',['Nazwisko',['../class_silnik_1_1_klient_indywidualny.html#ab5a0bdb5ed8412c91aeccb2833996607',1,'Silnik::KlientIndywidualny']]]
];
