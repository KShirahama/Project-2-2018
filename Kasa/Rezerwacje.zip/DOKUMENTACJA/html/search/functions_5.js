var searchData=
[
  ['main',['Main',['../class_system_zarzadzania_1_1_app.html#afc35a78a384092bf9baa0d4c310c2ebe',1,'SystemZarzadzania.App.Main()'],['../class_system_zarzadzania_1_1_app.html#afc35a78a384092bf9baa0d4c310c2ebe',1,'SystemZarzadzania.App.Main()']]]
];
