var searchData=
[
  ['klientindywidualny',['KlientIndywidualny',['../class_silnik_1_1_klient_indywidualny.html#aad71a96b2d0b01f88f7a4f409f43f28b',1,'Silnik::KlientIndywidualny']]]
];
