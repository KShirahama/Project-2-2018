var searchData=
[
  ['app',['App',['../class_system_zarzadzania_1_1_app.html',1,'SystemZarzadzania']]],
  ['archiwum',['Archiwum',['../class_silnik_1_1_archiwum.html',1,'Silnik']]]
];
