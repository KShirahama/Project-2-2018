var searchData=
[
  ['klient',['Klient',['../class_silnik_1_1_klient.html',1,'Silnik.Klient'],['../class_silnik_1_1_bilet.html#a04776d4ea2042538d57da9f3d35f3703',1,'Silnik.Bilet.Klient()']]],
  ['klientindywidualny',['KlientIndywidualny',['../class_silnik_1_1_klient_indywidualny.html',1,'Silnik.KlientIndywidualny'],['../class_silnik_1_1_klient_indywidualny.html#aad71a96b2d0b01f88f7a4f409f43f28b',1,'Silnik.KlientIndywidualny.KlientIndywidualny()']]]
];
