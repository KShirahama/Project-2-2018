var searchData=
[
  ['initializecomponent',['InitializeComponent',['../class_system_zarzadzania_1_1_app.html#ac1f3db202350dcc6d30936a6ddf65a86',1,'SystemZarzadzania.App.InitializeComponent()'],['../class_system_zarzadzania_1_1_app.html#ac1f3db202350dcc6d30936a6ddf65a86',1,'SystemZarzadzania.App.InitializeComponent()'],['../class_system_zarzadzania_1_1_main_window.html#a6bf2b1fe2c258d549c389267f9053051',1,'SystemZarzadzania.MainWindow.InitializeComponent()'],['../class_system_zarzadzania_1_1_main_window.html#a6bf2b1fe2c258d549c389267f9053051',1,'SystemZarzadzania.MainWindow.InitializeComponent()']]]
];
